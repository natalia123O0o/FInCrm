import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap'; // Librería de animaciones principales
import { ScrollTrigger } from 'gsap/ScrollTrigger'; // Plugin de GSAP para sincronizar animaciones con el scroll
import { MOTION } from '../../../utils/constants.js'; // Constantes globales de animación y easings
import './manifesto.css';

// Registra ScrollTrigger dentro de la instancia global de GSAP
gsap.registerPlugin(ScrollTrigger);

// Texto destacado del manifiesto de marca que se revelará palabra por palabra
const TEXT = 'Cobrar con tranquilidad: cada contacto cumple la Ley 2300 y cada decisión queda registrada.';

/**
 * Componente Manifesto.
 * Presenta una declaración de la propuesta de valor de FinCRM.
 * Utiliza un efecto de fijado de pantalla (pinning) y lectura palabra por palabra
 * (scroll-driven word reveal) junto con la entrada de un tótem geométrico decorativo.
 */
export default function Manifesto() {
  // Referencia al contenedor HTML raíz de la sección
  const rootRef = useRef(null);
  // Referencia al elemento de párrafo donde se inyectarán las palabras
  const textRef = useRef(null);

  useLayoutEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    // Detecta la preferencia del usuario respecto a la reducción de movimiento
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Contexto de GSAP para aislar selectores de DOM y garantizar una limpieza adecuada
    const ctx = gsap.context(() => {
      // Divide el texto en un arreglo de palabras individuales
      const words = TEXT.split(' ');
      
      // Convierte cada palabra en un elemento <span> dinámico con la clase .mf__word
      textRef.current.innerHTML = words.map((w) => `<span class="mf__word">${w}</span>`).join(' ');
      
      // Selecciona todos los <span> creados
      const wordEls = textRef.current.querySelectorAll('.mf__word');
      
      // Establece la opacidad inicial baja (15%) para el efecto de texto atenazado/desenfocado
      gsap.set(wordEls, { opacity: 0.15 });

      // Si el usuario solicita movimiento reducido, muestra el texto y las formas completamente sin animación
      if (prefersReduced) {
        gsap.set(wordEls, { opacity: 1 });
        gsap.set('.mf__shape', { opacity: 1, x: 0, y: 0, rotation: 0 });
        return;
      }

      // Crea la línea de tiempo atada al avance del scroll (ScrollTrigger con scrub)
      const tl = gsap.timeline({
        scrollTrigger: { 
          trigger: root, 
          start: 'top top', // La sección se fija cuando la parte superior toca la pantalla
          end: '+=160%', // La fijación dura un 160% del alto de la ventana
          scrub: 0.8, // Suaviza la respuesta de la animación respecto al scroll del usuario (0.8s)
          pin: true, // Mantiene fija la sección en pantalla durante el recorrido del scroll
          anticipatePin: 1 // Evita saltos visuales durante el enganche inicial del pin
        },
      });

      // 1. Revelado progresivo de opacidad (15% -> 100%) palabra por palabra conforme se hace scroll
      tl.to(wordEls, { opacity: 1, stagger: { each: 0.05 }, duration: 0.4 });

      // 2. Entrada con rotación y rebote suave de las figuras del tótem desde los bordes de la pantalla
      tl.fromTo('.mf__shape--circle', { x: '120vw', rotation: 120, opacity: 0 }, { x: 0, rotation: 0, opacity: 1, duration: 1, ease: MOTION.ease.back }, 0)
        .fromTo('.mf__shape--orange', { x: '120vw', rotation: 120, opacity: 0 }, { x: 0, rotation: 0, opacity: 1, duration: 1, ease: MOTION.ease.back }, 0.1)
        .fromTo('.mf__shape--navy', { y: '60vh', opacity: 0 }, { y: 0, opacity: 1, duration: 1, ease: MOTION.ease.back }, 0.15)
        
        // 3. Desplazamiento horizontal ligero del bloque de texto para balancear la composición visual
        .to('.mf__text', { x: -40, duration: 1 }, '>-0.15');
    }, root);

    // Limpieza de GSAP y ScrollTrigger al desmontar
    return () => ctx.revert();
  }, []);

  return (
    <section className="mf" ref={rootRef} data-bg="light" data-nav-theme="light">
      <div className="container mf__grid">
        {/* Texto que se llena dinámicamente con las palabras agrupadas en <span> */}
        <p className="mf__text" ref={textRef}>{TEXT}</p>

        {/* Tótem decorativo compuesto por figuras geométricas vectoriales */}
        <div className="mf__totem" aria-hidden="true">
          <span className="mf__shape mf__shape--navy" />
          <span className="mf__shape mf__shape--circle" />
          <span className="mf__shape mf__shape--orange" />
        </div>
      </div>
    </section>
  );
}