import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { MOTION } from '../../../utils/constants.js';
import './preloader.css';

const KEY = 'fincrm_seen';

export default function Preloader({ onFinish }) {
  const rootRef = useRef(null);
  const barRefs = useRef([]);
  const wordRef = useRef(null);
  const doneRef = useRef(false);
  const onFinishRef = useRef(onFinish);

  // Mantiene siempre la última versión del callback sin reiniciar GSAP.
  onFinishRef.current = onFinish;

  useLayoutEffect(() => {
    const root = rootRef.current;

    if (!root) return undefined;

    let seen = false;

    try {
      seen = sessionStorage.getItem(KEY) === '1';
    } catch {
      seen = false;
    }

    const prefersReduced = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    const finish = () => {
      if (doneRef.current) return;

      doneRef.current = true;

      try {
        sessionStorage.setItem(KEY, '1');
      } catch {
        // sessionStorage puede estar bloqueado.
      }

      onFinishRef.current?.();
    };

    // Si el usuario no quiere animaciones, desaparece inmediatamente.
    if (prefersReduced) {
      gsap.set(root, {
        autoAlpha: 0,
        display: 'none',
      });

      finish();

      return undefined;
    }

    const ctx = gsap.context(() => {
      // ---------------------------------------------
      // VISITA PREVIA
      // ---------------------------------------------
      if (seen) {
        gsap.set(root, {
          autoAlpha: 1,
          yPercent: 0,
        });

        gsap.to(root, {
          autoAlpha: 0,
          duration: MOTION.duration.pageFade,
          ease: MOTION.ease.out,
          onComplete: () => {
            gsap.set(root, {
              display: 'none',
            });

            finish();
          },
        });

        return;
      }

      // ---------------------------------------------
      // PRIMERA VISITA
      // ---------------------------------------------
      const bars = barRefs.current.filter(Boolean);
      const arrow = root.querySelector('.preloader__arrow-path');

      gsap.set(bars, {
        scaleY: 0,
        transformOrigin: '50% 100%',
      });

      if (arrow) {
        gsap.set(arrow, {
          strokeDasharray: 400,
          strokeDashoffset: 400,
        });
      }

      gsap.set(wordRef.current, {
        opacity: 0,
        y: 16,
      });

      gsap.set(root, {
        yPercent: 0,
        autoAlpha: 1,
      });

      const tl = gsap.timeline({
        onComplete: () => {
          gsap.set(root, {
            display: 'none',
          });

          finish();
        },
      });

      tl.to(bars, {
        scaleY: 1,
        duration: MOTION.duration.preloaderBars,
        stagger: MOTION.stagger.md,
        ease: MOTION.ease.back,
      });

      if (arrow) {
        tl.to(
          arrow,
          {
            strokeDashoffset: 0,
            duration: MOTION.duration.preloaderArrow,
            ease: MOTION.ease.out,
          },
          '-=0.15'
        );
      }

      tl.to(
        wordRef.current,
        {
          opacity: 1,
          y: 0,
          duration: MOTION.duration.preloaderWord,
          ease: MOTION.ease.out,
        },
        '-=0.1'
      );

      tl.to(
        root,
        {
          yPercent: -100,
          duration: MOTION.duration.preloaderLift,
          ease: MOTION.ease.inOut,
        },
        '+=0.15'
      );
    }, root);

    return () => {
      ctx.revert();
    };
  }, []);

  return (
    <div
      ref={rootRef}
      className="preloader"
      aria-hidden="true"
    >
      <div className="preloader__inner">
        <svg
          className="preloader__mark"
          viewBox="0 0 120 140"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            ref={(el) => {
              barRefs.current[0] = el;
            }}
            x="10"
            y="70"
            width="30"
            height="60"
            rx="8"
            fill="#F97316"
          />

          <rect
            ref={(el) => {
              barRefs.current[1] = el;
            }}
            x="45"
            y="40"
            width="30"
            height="90"
            rx="8"
            fill="#06B6D4"
          />

          <rect
            ref={(el) => {
              barRefs.current[2] = el;
            }}
            x="80"
            y="10"
            width="30"
            height="120"
            rx="8"
            fill="#F8FAFC"
          />

          <path
            className="preloader__arrow-path"
            d="M5 100 L40 60 L70 80 L115 20"
            fill="none"
            stroke="#06B6D4"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>

        <span
          ref={wordRef}
          className="preloader__word"
        >
          FinCRM
        </span>
      </div>
    </div>
  );
}