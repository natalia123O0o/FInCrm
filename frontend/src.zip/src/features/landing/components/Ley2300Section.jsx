import { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap'; // Librería de animaciones principales
import { ScrollTrigger } from 'gsap/ScrollTrigger'; // Plugin de GSAP para animaciones atadas al scroll
import { MOTION } from '../../../utils/constants.js'; // Constantes globales de animación y timings
import ModuleDetailModal from '../../catalog/components/ModuleDetailModal.jsx'; // Componente modal con los detalles técnicos del módulo
import './ley2300-section.css';

// Registra ScrollTrigger dentro de la instancia de GSAP
gsap.registerPlugin(ScrollTrigger);

// Objeto con la información detallada del módulo de la Ley 2300 para el modal
const LEY_MODULE = {
  title: 'Algoritmo de Control Preventivo (Ley 2300)',
  detail: {
    technical: 'Motor de reglas determinista que evalúa RNE, horarios (L–V 7:00–19:00, Sáb 8:00–15:00), frecuencia (máx. 1 contacto semanal) y festivos colombianos. Cada intento se registra en la bitácora con estado Permitido, Encolado o Bloqueado.',
    interop: 'Bitácora por tenant exportable a CSV. Job programado reevalúa encolados cada minuto en zona America/Bogota.',
    impact: 'Cero sanciones, cero llamadas fuera de horario y una operación de cobranza sostenida que acelera el recaudo.',
  },
};

/**
 * Componente Ley2300Section.
 * Presenta la sección dedicada al cumplimiento de la Ley 2300 en Colombia (dejen de fregar).
 * Incluye un stack de tarjetas apiladas mediante scroll fijado (pinning), reveal de clip-path,
 * parallax en el tótem decorativo y micro-animaciones en barras, días y tabla de bitácora.
 */
export default function Ley2300Section() {
  // Referencia a la sección raíz de la Ley 2300
  const rootRef = useRef(null);
  // Referencia al contenedor de tarjetas apiladas que se fijará en pantalla
  const stackRef = useRef(null);
  // Estado para controlar la visibilidad del modal explicativo
  const [open, setOpen] = useState(false);

  useLayoutEffect(() => {
    const root = rootRef.current;
    const stack = stackRef.current;
    if (!root || !stack) return;

    // Detecta la preferencia de reducción de movimiento del sistema
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Contexto de GSAP para garantizar limpieza y aislar los selectores DOM
    const ctx = gsap.context(() => {
      // Instancia de matchMedia de GSAP para manejar animaciones responsivas
      const mm = gsap.matchMedia();

      // ==========================================
      // ANIMACIONES PARA ESCRITORIO (>= 1024px)
      // ==========================================
      mm.add('(min-width: 1024px)', () => {
        // Si el usuario prefiere movimiento reducido, muestra todo estático sin animaciones
        if (prefersReduced) {
          gsap.set('.ley-card', { yPercent: 0, opacity: 1 });
          gsap.set('.ley__wedge', { clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)' });
          return;
        }

        // 1. Animación de revelado diagonal de fondo (Wedge clip-path)
        gsap.fromTo('.ley__wedge',
          { clipPath: 'polygon(100% 0, 100% 0, 100% 0, 100% 0)' },
          { 
            clipPath: 'polygon(100% 0, 100% 100%, 0 100%, 0 0)', 
            ease: 'none',
            scrollTrigger: { trigger: root, start: 'top 80%', end: 'top 20%', scrub: 1 } 
          }
        );

        // 2. Parallax vertical del tótem geométrico gigante
        gsap.fromTo('.ley__big-totem',
          { y: '100vh', opacity: 0.25 },
          { 
            y: '-10vh', 
            ease: 'none',
            scrollTrigger: { trigger: root, start: 'top 80%', end: 'top -20%', scrub: 1 } 
          }
        );

        // 3. Efecto de Tarjetas Apiladas (Card Stacking)
        const cards = gsap.utils.toArray('.ley-card');
        gsap.set(cards[0], { yPercent: 0 }); // La primera tarjeta inicia visible
        gsap.set(cards.slice(1), { yPercent: 100 }); // Las tarjetas subsiguientes inician abajo

        // Timeline con fijado de pantalla (pin: true)
        const tl = gsap.timeline({
          scrollTrigger: { 
            trigger: stack, 
            start: 'top top', 
            end: '+=300%', 
            scrub: 0.8, 
            pin: true, 
            anticipatePin: 1 
          },
        });

        // Secuencia que escala y reduce opacidad de la tarjeta previa mientras sube la nueva
        cards.forEach((card, i) => {
          if (i === 0) return;
          tl.to(cards[i - 1], { y: '-4%', scale: 0.96, opacity: 0.7, duration: 0.5, ease: 'power2.out' }, i - 1)
            .to(card, { yPercent: 0, duration: 1, ease: 'power2.out' }, i - 1);
        });
      });

      // ==========================================
      // ANIMACIONES PARA MÓVIL/TABLET (< 1024px)
      // ==========================================
      mm.add('(max-width: 1023px)', () => {
        // Entrada estándar con desplazamiento vertical y opacidad tarjeta por tarjeta
        gsap.utils.toArray('.ley-card').forEach((card) => {
          gsap.from(card, { 
            y: 40, 
            opacity: 0, 
            duration: 0.8, 
            ease: MOTION.ease.out, 
            scrollTrigger: { trigger: card, start: 'top 85%' } 
          });
        });
      });

      // ==========================================
      // MICRO-ANIMACIONES INTERNAS DE LAS TARJETAS
      // ==========================================
      
      // Animación de llenado de las barras de horarios (L-V y Sáb)
      gsap.from('.ley__schedule-fill', { 
        scaleX: 0, 
        transformOrigin: 'left center', 
        duration: 0.8, 
        ease: MOTION.ease.out, 
        scrollTrigger: { trigger: '.ley-card--horarios', start: 'top 70%' } 
      });

      // Animación de impulso/pop en el día activo de frecuencia (Miércoles)
      gsap.from('.ley__day--active', { 
        scale: 0.6, 
        duration: 0.6, 
        ease: MOTION.ease.backMax, 
        scrollTrigger: { trigger: '.ley-card--frecuencia', start: 'top 70%' } 
      });

      // Entrada en cascada de las filas de la bitácora auditable
      gsap.from('.ley__row', { 
        y: 16, 
        opacity: 0, 
        duration: 0.6, 
        stagger: MOTION.stagger.lg, 
        ease: MOTION.ease.out, 
        scrollTrigger: { trigger: '.ley-card--bitacora', start: 'top 70%' } 
      });

      // Animación de escalado con rebote en los badges de estado (Permitido, Encolado, Bloqueado)
      gsap.from('.ley__badge', { 
        scale: 0.7, 
        duration: 0.6, 
        stagger: MOTION.stagger.sm, 
        ease: MOTION.ease.backMax, 
        scrollTrigger: { trigger: '.ley-card--bitacora', start: 'top 70%' } 
      });
    }, root);

    // Limpieza de animaciones y triggers al desmontar el componente
    return () => ctx.revert();
  }, []);

  return (
    <section id="ley-2300" ref={rootRef} className="ley section" data-bg="navy" data-nav-theme="dark">
      {/* Cuña diagonal de fondo cortada dinámicamente con clip-path */}
      <div className="ley__wedge" aria-hidden="true" />
      
      {/* Tótem decorativo geométrico con efecto parallax */}
      <div className="ley__big-totem" aria-hidden="true">
        <span className="ley__big-square ley__big-square--navy" />
        <span className="ley__big-circle" />
        <span className="ley__big-square ley__big-square--orange" />
      </div>

      {/* Encabezado e introducción de la sección */}
      <div className="container ley__intro">
        <span className="section-label" style={{ color: 'var(--cyan)' }}>Cumplimiento</span>
        <h2 className="ley__title">Ley 2300, aplicada sin fricción.</h2>
        <p className="ley__lead">Todo contacto de cobranza pasa por un motor de reglas que verifica horarios, frecuencia y RNE antes de ejecutarse.</p>
      </div>

      {/* Stack de tarjetas fijadas durante el scroll */}
      <div className="ley__stack" ref={stackRef}>
        {/* Tarjeta 01: Horarios de contacto */}
        <article className="ley-card ley-card--horarios">
          <div className="ley-card__head"><span className="ley-card__num">01</span><h3>Horarios</h3></div>
          <p>Lunes a viernes 7:00–19:00, sábados 8:00–15:00. Domingos y festivos: prohibido contactar.</p>
          <div className="ley__schedule">
            <div className="ley__schedule-row"><span>L–V</span><div className="ley__schedule-bar"><div className="ley__schedule-fill" style={{ width: '100%' }} /></div></div>
            <div className="ley__schedule-row"><span>Sáb</span><div className="ley__schedule-bar"><div className="ley__schedule-fill" style={{ width: '58%' }} /></div></div>
          </div>
          <div className="ley-card__mini-totem" aria-hidden="true"><span className="mini mini--navy" /><span className="mini mini--cyan" /></div>
        </article>

        {/* Tarjeta 02: Control de frecuencia */}
        <article className="ley-card ley-card--frecuencia">
          <div className="ley-card__head"><span className="ley-card__num">02</span><h3>Frecuencia</h3></div>
          <p>Máximo un contacto semanal por deudor.</p>
          <div className="ley__week">
            {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => (
              <span key={i} className={`ley__day ${i === 2 ? 'ley__day--active' : ''}`}>{d}</span>
            ))}
          </div>
          <div className="ley-card__mini-totem" aria-hidden="true"><span className="mini mini--cyan" /><span className="mini mini--orange" /></div>
        </article>

        {/* Tarjeta 03: Bitácora auditable */}
        <article className="ley-card ley-card--bitacora">
          <div className="ley-card__head"><span className="ley-card__num">03</span><h3>Bitácora auditable</h3></div>
          <p>Cada intento queda registrado con estado y motivo.</p>
          <div className="ley__table">
            <div className="ley__row"><span className="ley__badge ley__badge--ok">Permitido</span><span>Factura #1042 · 09:12</span></div>
            <div className="ley__row"><span className="ley__badge ley__badge--warn">Encolado</span><span>Factura #1043 · 19:30</span></div>
            <div className="ley__row"><span className="ley__badge ley__badge--danger">Bloqueado</span><span>Factura #1044 · 20:05</span></div>
          </div>
          <button className="btn btn--onDark" onClick={() => setOpen(true)} aria-label="Conocer el módulo de Ley 2300">Conocer el módulo</button>
        </article>
      </div>

      {/* Modal con especificaciones técnicas detalladas del módulo */}
      <ModuleDetailModal open={open} module={LEY_MODULE} onClose={() => setOpen(false)} />
    </section>
  );
}