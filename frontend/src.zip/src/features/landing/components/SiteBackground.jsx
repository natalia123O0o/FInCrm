import { useEffect } from 'react';
import { gsap } from 'gsap'; // Librería de animaciones principales
import { ScrollTrigger } from 'gsap/ScrollTrigger'; // Plugin de GSAP para activar eventos según la posición del scroll
import { SECTION_BG } from '../../../utils/constants.js'; // Mapa/Objeto de configuración con las claves y valores hexadecimales de color

// Registra el plugin ScrollTrigger dentro de la instancia global de GSAP
gsap.registerPlugin(ScrollTrigger);

/**
 * Componente SiteBackground.
 * Renderiza un contenedor fijo en el fondo que cambia suavemente de color
 * a medida que el usuario hace scroll sobre las secciones del sitio marcadas con el atributo 'data-bg'.
 */
export default function SiteBackground() {
  useEffect(() => {
    // Busca todas las secciones del DOM que tengan el atributo de datos 'data-bg'
    const sections = document.querySelectorAll('[data-bg]');
    // Selecciona la capa física del fondo
    const bg = document.querySelector('.site-bg');
    
    // Si no existen secciones con 'data-bg' o no se encuentra el elemento de fondo, interrumpe la ejecución
    if (!sections.length || !bg) return;

    // Arreglo para almacenar cada instancia de ScrollTrigger y poder destruirlas en la limpieza
    const triggers = [];

    // Recorre cada sección encontrada para asignarle su correspondiente observador de scroll
    sections.forEach((section) => {
      // Obtiene el color correspondiente del diccionario SECTION_BG usando el valor del atributo dataset.bg;
      // si no coincide ninguna clave, aplica el color por defecto (SECTION_BG.light)
      const color = SECTION_BG[section.dataset.bg] || SECTION_BG.light;

      // Crea la instancia de ScrollTrigger y la añade al listado
      triggers.push(
        ScrollTrigger.create({
          trigger: section, // Elemento que activa la transición al entrar en vista
          start: 'top 55%', // La zona de activación se sitúa cuando la parte superior de la sección alcanza el 55% de la pantalla
          end: 'bottom 55%', // Finaliza cuando la parte inferior de la sección alcanza el 55% de la pantalla
          
          // Se ejecuta cuando el scroll baja y la sección entra en la zona definida
          onEnter: () => gsap.to(bg, { backgroundColor: color, duration: 0.5 }),
          
          // Se ejecuta cuando el scroll sube e ingresa nuevamente a la sección desde abajo
          onEnterBack: () => gsap.to(bg, { backgroundColor: color, duration: 0.5 }),
        })
      );
    });

    // Función de limpieza de useEffect: destruye (kill) cada ScrollTrigger para liberar memoria y evitar memory leaks
    return () => triggers.forEach((t) => t.kill());
  }, []); // Se ejecuta únicamente al montar el componente

  // Contenedor HTML del fondo (oculto para lectores de pantalla mediante aria-hidden)
  return <div className="site-bg" aria-hidden="true" />;
}