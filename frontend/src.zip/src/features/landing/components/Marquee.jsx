import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MOTION } from '../../../utils/constants.js';
import { getLenis } from '../../../hooks/useLenis.js';
import './marquee.css';

gsap.registerPlugin(ScrollTrigger);

const WORDS = [
  'Facturación electrónica DIAN',
  'Ley 2300',
  'RNE',
  'Chatbot IA',
  'Flujo de caja',
  'Cartera',
  'Bitácora auditable',
];

const COLORS = ['#F97316', '#06B6D4', '#0284C7'];

export default function Marquee() {
  const rootRef = useRef(null);
  const trackRef = useRef(null);

  useLayoutEffect(() => {
    const root = rootRef.current;
    const track = trackRef.current;

    if (!root || !track) return undefined;

    const prefersReduced = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    if (prefersReduced) {
      return undefined;
    }

    let lenis = null;
    let lenisHandler = null;
    let rafId = null;

    const ctx = gsap.context(() => {
      const tween = gsap.to(track, {
        xPercent: -50,
        duration: MOTION.marquee.duration,
        ease: 'none',
        repeat: -1,
      });

      const slow = () => {
        gsap.to(tween, {
          timeScale: MOTION.marquee.hoverSlow,
          duration: 0.4,
          overwrite: true,
        });
      };

      const normal = () => {
        gsap.to(tween, {
          timeScale: 1,
          duration: 0.4,
          overwrite: true,
        });
      };

      root.addEventListener('mouseenter', slow);
      root.addEventListener('mouseleave', normal);

      // Esperamos al siguiente frame porque Lenis se inicializa
      // desde App.jsx y el efecto de este componente puede ejecutarse antes.
      rafId = requestAnimationFrame(() => {
        lenis = getLenis();

        if (!lenis) return;

        lenisHandler = ({ velocity }) => {
          const target = Math.min(
            1 + Math.abs(velocity) / MOTION.marquee.velocityDivisor,
            MOTION.marquee.maxTimeScale
          );

          gsap.to(tween, {
            timeScale: target,
            duration: 0.25,
            overwrite: true,
          });
        };

        lenis.on('scroll', lenisHandler);
      });

      gsap.from(root, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: MOTION.ease.out,
        scrollTrigger: {
          trigger: root,
          start: 'top 90%',
          once: true,
        },
      });
    }, root);

    return () => {
      if (rafId) {
        cancelAnimationFrame(rafId);
      }

      if (lenis && lenisHandler) {
        lenis.off('scroll', lenisHandler);
      }

      root.removeEventListener('mouseenter', () => {});
      root.removeEventListener('mouseleave', () => {});

      ctx.revert();
    };
  }, []);

  return (
    <section
      className="marquee"
      ref={rootRef}
      aria-hidden="true"
    >
      <div
        className="marquee__track"
        ref={trackRef}
      >
        {[0, 1].map((dup) => (
          <ul
            className="marquee__list"
            key={dup}
          >
            {WORDS.map((word, index) => (
              <li
                key={`${dup}-${word}`}
                className="marquee__item"
              >
                <span
                  className="marquee__dot"
                  style={{
                    background: COLORS[index % COLORS.length],
                  }}
                />

                <span>{word}</span>
              </li>
            ))}
          </ul>
        ))}
      </div>
    </section>
  );
}