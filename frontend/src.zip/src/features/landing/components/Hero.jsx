import { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap'; // Librería de animación principal
import { MOTION } from '../../../utils/constants.js'; // Constantes globales de duraciones, easings y deltas de parallax
import { scrollToSection } from '../../../hooks/useLenis.js'; // Función utilitaria para scroll suave hacia anclas de sección
import './hero.css';

/**
 * Componente Hero.
 * Sección principal de bienvenida para FinCRM. Coordina la entrada visual animada de los títulos,
 * botones de acción, animación de mockup con conteo de KPIs formateados en COP y efectos parallax.
 *
 * @param {Object} props - Propiedades del componente.
 * @param {boolean} props.ready - Estado booleano que indica si el Preloader terminó para iniciar las animaciones.
 */
export default function Hero({ ready }) {
  // Referencia al contenedor raíz del Hero para aislar los selectores de GSAP
  const rootRef = useRef(null);

  useLayoutEffect(() => {
    // Si la pantalla de carga aún está activa, no ejecuta las animaciones
    if (!ready) return;
    const root = rootRef.current;
    if (!root) return;

    // Consulta si el usuario prefiere movimiento reducido según la configuración de su sistema
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      // Si se solicita movimiento reducido, muestra los elementos directamente sin animación
      gsap.set(root.querySelectorAll('.hero__line-inner'), { yPercent: 0 });
      gsap.set(root.querySelector('.hero__mockup'), { clipPath: 'inset(0 0 0% 0)', scale: 1 });
      return;
    }

    // Contexto de GSAP para aislar selecciones y facilitar la recolección de basura
    const ctx = gsap.context(() => {
      // Línea de tiempo principal de entrada
      const tl = gsap.timeline({ defaults: { ease: MOTION.ease.out } });

      // Configuración de estados iniciales (ocultos o fuera de posición)
      gsap.set('.hero__line-inner', { yPercent: 110 }); // Texto del H1 oculto bajo la máscara
      gsap.set('.hero__mockup', { clipPath: 'inset(0 0 100% 0)', scale: 1.08 }); // Mockup recortado al 100% desde abajo
      gsap.set('.hero__sub, .hero__cta', { y: 24, opacity: 0 }); // Subtítulo y botones desplazados hacia abajo y transparentes

      // Secuencia de entrada paso a paso
      tl.to('.hero__line-inner', { yPercent: 0, duration: 0.9, stagger: MOTION.stagger.md }) // 1. Revelado tipo máscara del título H1
        .to('.hero__sub', { y: 0, opacity: 1, duration: 0.7 }, '-=0.55') // 2. Desvanecimiento hacia arriba del subtítulo
        .to('.hero__cta', { y: 0, opacity: 1, duration: 0.7, stagger: MOTION.stagger.md }, '-=0.45') // 3. Entrada escalonada de botones CTA
        .to('.hero__mockup', { clipPath: 'inset(0 0 0% 0)', scale: 1, duration: MOTION.duration.heroMockup, ease: 'power3.inOut' }, '-=0.6') // 4. Desvelado del mockup de la interfaz
        .fromTo('.hero__bar', { scaleY: 0, transformOrigin: '50% 100%' }, { scaleY: 1, duration: 0.6, stagger: MOTION.stagger.sm, ease: MOTION.ease.backSoft }, '-=0.4'); // 5. Crecimiento de las barras del gráfico

      // Animación de contadores numéricos (KPIs) con interpolación de valores
      root.querySelectorAll('[data-count]').forEach((el) => {
        const to = parseFloat(el.dataset.count); // Valor numérico objetivo
        const isCOP = el.dataset.format === 'cop'; // Revisa si requiere formato de moneda colombiana
        const obj = { v: 0 };

        gsap.to(obj, {
          v: to, duration: 1.2, ease: 'power2.out', delay: 0.6,
          onUpdate: () => {
            // Formatea dinámicamente como moneda en COP o entero con separadores de miles es-CO
            el.textContent = isCOP
              ? `$${Math.round(obj.v).toLocaleString('es-CO')}`
              : Math.round(obj.v).toLocaleString('es-CO');
          },
        });
      });

      // Efecto Parallax: Desplazamiento del mockup durante el scroll
      gsap.to('.hero__mockup', {
        y: MOTION.parallax.mockupY, ease: 'none',
        scrollTrigger: { trigger: root, start: 'top top', end: 'bottom top', scrub: MOTION.parallax.scrub },
      });

      // Efecto Parallax: Desplazamiento del texto a una velocidad sutilmente distinta
      gsap.to('.hero__text', {
        y: MOTION.parallax.textY, ease: 'none',
        scrollTrigger: { trigger: root, start: 'top top', end: 'bottom top', scrub: MOTION.parallax.scrub },
      });

      // Animación flotante continua (Loop) para las formas geométricas decorativas
      gsap.utils.toArray('.hero__shape').forEach((el, i) => {
        gsap.to(el, { y: '+=14', rotation: i % 2 === 0 ? 6 : -6, duration: 4 + i * 0.6, yoyo: true, repeat: -1, ease: 'sine.inOut' });
      });
    }, root);

    // Limpieza de animaciones al desmontar o cambiar la dependencia 'ready'
    return () => ctx.revert();
  }, [ready]);

  return (
    <section id="inicio" ref={rootRef} className="hero section" data-bg="light" data-nav-theme="light">
      <div className="container hero__grid">
        
        {/* Columna Izquierda: Información principal y llamados a la acción */}
        <div className="hero__text">
          <div className="hero__logo-big"><img src="/logo-fincrm.png" alt="FinCRM" /></div>

          <h1 className="hero__h1">
            <span className="hero__line"><span className="hero__line-inner">Optimiza tu flujo de caja</span></span>
            <span className="hero__line"><span className="hero__line-inner">y cumple la Ley 2300.</span></span>
          </h1>

          <p className="hero__sub">
            CRM SaaS de cobranza para PYMES colombianas. Facturación electrónica simulada, control preventivo y un chatbot que negocia acuerdos de pago sin salirse de la norma.
          </p>

          <div className="hero__actions">
            <button className="btn btn--primary hero__cta" onClick={() => scrollToSection('#contacto')} aria-label="Solicitar demo">Solicitar demo</button>
            <button className="btn btn--ghost hero__cta" onClick={() => scrollToSection('#modulos')} aria-label="Ver módulos">Ver módulos</button>
          </div>
        </div>

        {/* Columna Derecha: Previsualización interactiva simulada (Mockup de dashboard) */}
        <div className="hero__mockup" aria-hidden="true">
          
          {/* Fila de Tarjetas KPI con lectura interactiva */}
          <div className="hero__kpi-row">
            <div className="hero__kpi"><span className="hero__kpi-label">Cartera total</span><strong data-count="128450000" data-format="cop">$0</strong></div>
            <div className="hero__kpi"><span className="hero__kpi-label">Facturas pendientes</span><strong data-count="42">0</strong></div>
            <div className="hero__kpi"><span className="hero__kpi-label">Contactos permitidos hoy</span><strong data-count="7">0</strong></div>
          </div>

          {/* Gráfico de barras simulado para recaudo */}
          <div className="hero__chart">
            <div className="hero__chart-title">Recaudo últimos 8 meses</div>
            <div className="hero__bars">
              {[30, 42, 55, 48, 70, 82, 95, 110].map((h, i) => (
                <span key={i} className="hero__bar" style={{ height: `${h}px` }} />
              ))}
            </div>
          </div>

          {/* Formas geométricas flotantes decorativas */}
          <span className="hero__shape hero__shape--circle" />
          <span className="hero__shape hero__shape--square" />
          <span className="hero__shape hero__shape--dot" />
        </div>

      </div>
    </section>
  );
}