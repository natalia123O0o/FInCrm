import { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MOTION } from '../../../utils/constants.js';
import ModuleGrid from '../../catalog/components/ModuleGrid.jsx';
import ModuleDetailModal from '../../catalog/components/ModuleDetailModal.jsx';
import { MODULES } from '../../catalog/data/modules.data.js';
import './modules-section.css';

gsap.registerPlugin(ScrollTrigger);

export default function ModulesSection() {
  const rootRef = useRef(null);
  const [openId, setOpenId] = useState(null);

  useLayoutEffect(() => {
    const root = rootRef.current;

    if (!root) return undefined;

    const prefersReduced = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    const ctx = gsap.context(() => {
      const titleInner = root.querySelectorAll(
        '.modules__title-line-inner'
      );

      const cards = root.querySelectorAll('.module-card');
      const icons = root.querySelectorAll('.module-card__icon');
      const grid = root.querySelector('.modules__grid');

      // Movimiento reducido:
      // dejamos todo visible y no creamos ScrollTriggers.
      if (prefersReduced) {
        gsap.set(titleInner, {
          yPercent: 0,
          clearProps: 'transform',
        });

        gsap.set(cards, {
          y: 0,
          opacity: 1,
          clearProps: 'transform,opacity',
        });

        gsap.set(icons, {
          rotation: 0,
          scale: 1,
          clearProps: 'transform',
        });

        return;
      }

      // ---------------------------------------------
      // TÍTULO
      // ---------------------------------------------
      gsap.set(titleInner, {
        yPercent: 110,
      });

      gsap.to(titleInner, {
        yPercent: 0,
        duration: 0.9,
        stagger: MOTION.stagger.md,
        ease: MOTION.ease.out,
        scrollTrigger: {
          trigger: root,
          start: 'top 80%',
          once: true,
        },
      });

      // ---------------------------------------------
      // TARJETAS
      // ---------------------------------------------
      if (grid && cards.length) {
        gsap.from(cards, {
          y: 60,
          opacity: 0,
          duration: 0.9,
          ease: MOTION.ease.out,
          stagger: MOTION.stagger.lg,
          scrollTrigger: {
            trigger: grid,
            start: 'top 85%',
            once: true,
          },
        });
      }

      // ---------------------------------------------
      // ICONOS
      // ---------------------------------------------
      if (grid && icons.length) {
        gsap.from(icons, {
          rotation: -25,
          scale: 0.5,
          duration: 0.8,
          ease: MOTION.ease.backStrong,
          stagger: MOTION.stagger.lg,
          scrollTrigger: {
            trigger: grid,
            start: 'top 85%',
            once: true,
          },
        });
      }
    }, root);

    return () => {
      ctx.revert();
    };
  }, []);

  return (
    <section
      id="modulos"
      ref={rootRef}
      className="modules section"
      data-bg="gray"
      data-nav-theme="light"
    >
      <div className="container">
        <span className="section-label">
          Módulos
        </span>

        <h2 className="modules__title">
          <span className="modules__title-line">
            <span className="modules__title-line-inner">
              Cuatro módulos,
            </span>
          </span>

          <span className="modules__title-line">
            <span className="modules__title-line-inner">
              una sola operación.
            </span>
          </span>
        </h2>

        <ModuleGrid onOpen={setOpenId} />
      </div>

      <ModuleDetailModal
        open={openId !== null}
        module={MODULES.find((module) => module.id === openId)}
        onClose={() => setOpenId(null)}
      />
    </section>
  );
}