import {
  useLayoutEffect,
  useRef,
  useState,
} from 'react';

import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import { MOTION } from '../../../utils/constants.js';
import ContactForm from '../../contact/components/ContactForm.jsx';

import './contact-section.css';

gsap.registerPlugin(ScrollTrigger);

export default function ContactSection() {
  const rootRef = useRef(null);
  const formWrapRef = useRef(null);
  const successRef = useRef(null);

  const [success, setSuccess] = useState(false);

  // ---------------------------------------------
  // ANIMACIONES DE SCROLL
  // ---------------------------------------------
  useLayoutEffect(() => {
    const root = rootRef.current;

    if (!root) return undefined;

    const prefersReduced = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    const ctx = gsap.context(() => {
      const fields = root.querySelectorAll('.cf__field');
      const bars = root.querySelectorAll('.cf-illustration__bar');
      const illustration = root.querySelector('.cf-illustration');
      const arrow = root.querySelector('.cf-illustration__arrow');

      if (prefersReduced) {
        gsap.set(fields, {
          y: 0,
          opacity: 1,
          clearProps: 'transform,opacity',
        });

        gsap.set(bars, {
          scaleY: 1,
          clearProps: 'transform',
        });

        if (arrow) {
          gsap.set(arrow, {
            strokeDasharray: 'none',
            strokeDashoffset: 0,
            clearProps: 'strokeDasharray,strokeDashoffset',
          });
        }

        return;
      }

      // ---------------------------------------------
      // CAMPOS DEL FORMULARIO
      // ---------------------------------------------
      if (fields.length) {
        gsap.from(fields, {
          y: 24,
          opacity: 0,
          duration: 0.7,
          stagger: MOTION.stagger.sm,
          ease: MOTION.ease.out,
          scrollTrigger: {
            trigger: root,
            start: 'top 80%',
            once: true,
          },
        });
      }

      // ---------------------------------------------
      // BARRAS
      // ---------------------------------------------
      if (illustration && bars.length) {
        gsap.from(bars, {
          scaleY: 0,
          transformOrigin: '50% 100%',
          stagger: MOTION.stagger.xl,
          ease: 'none',
          scrollTrigger: {
            trigger: illustration,
            start: 'top 80%',
            end: 'bottom 40%',
            scrub: 1,
          },
        });
      }

      // ---------------------------------------------
      // FLECHA
      // ---------------------------------------------
      if (illustration && arrow) {
        gsap.set(arrow, {
          strokeDasharray: 500,
          strokeDashoffset: 500,
        });

        gsap.to(arrow, {
          strokeDashoffset: 0,
          ease: 'none',
          scrollTrigger: {
            trigger: illustration,
            start: 'top 80%',
            end: 'bottom 40%',
            scrub: 1,
          },
        });
      }
    }, root);

    return () => {
      ctx.revert();
    };
  }, []);

  // ---------------------------------------------
  // ANIMACIÓN DEL MENSAJE DE ÉXITO
  // ---------------------------------------------
  useLayoutEffect(() => {
    if (!success) return undefined;

    const successElement = successRef.current;

    if (!successElement) return undefined;

    const prefersReduced = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    const ctx = gsap.context(() => {
      const circle = successElement.querySelector(
        '.cf-success__circle'
      );

      const check = successElement.querySelector(
        '.cf-success__check'
      );

      if (prefersReduced) {
        gsap.set(successElement, {
          opacity: 1,
        });

        gsap.set(circle, {
          scale: 1,
        });

        if (check) {
          gsap.set(check, {
            strokeDasharray: 'none',
            strokeDashoffset: 0,
          });
        }

        return;
      }

      gsap.set(successElement, {
        opacity: 0,
      });

      gsap.set(circle, {
        scale: 0,
        transformOrigin: '50% 50%',
      });

      if (check) {
        gsap.set(check, {
          strokeDasharray: 60,
          strokeDashoffset: 60,
        });
      }

      const tl = gsap.timeline();

      tl.to(successElement, {
        opacity: 1,
        duration: 0.4,
        ease: MOTION.ease.out,
      });

      tl.to(
        circle,
        {
          scale: 1,
          duration: 0.6,
          ease: MOTION.ease.backMax,
        },
        '-=0.1'
      );

      if (check) {
        tl.to(
          check,
          {
            strokeDashoffset: 0,
            duration: 0.5,
            ease: MOTION.ease.out,
          },
          '-=0.2'
        );
      }
    }, successElement);

    return () => {
      ctx.revert();
    };
  }, [success]);

  // ---------------------------------------------
  // ENVÍO EXITOSO
  // ---------------------------------------------
  const handleSuccess = () => {
    const form = formWrapRef.current;

    if (form) {
      const prefersReduced = window.matchMedia(
        '(prefers-reduced-motion: reduce)'
      ).matches;

      if (prefersReduced) {
        gsap.set(form, {
          display: 'none',
        });
      } else {
        gsap.to(form, {
          opacity: 0,
          duration: 0.3,
          ease: MOTION.ease.out,
          onComplete: () => {
            if (form) {
              gsap.set(form, {
                display: 'none',
              });
            }
          },
        });
      }
    }

    // React monta primero el mensaje.
    // El useLayoutEffect de arriba se encarga de animarlo.
    setSuccess(true);
  };

  return (
    <section
      id="contacto"
      ref={rootRef}
      className="contact section"
      data-bg="light"
      data-nav-theme="light"
    >
      <div className="container contact__grid">
        <div
          className="contact__form-wrap"
          ref={formWrapRef}
        >
          <span className="section-label">
            Contacto
          </span>

          <h2 className="contact__title">
            Solicita tu demo.
          </h2>

          <p className="contact__lead">
            Cuéntanos sobre tu PYME y te mostramos
            FinCRM en una sesión de 20 minutos.
          </p>

          <ContactForm onSuccess={handleSuccess} />
        </div>

        {success && (
          <div
            className="cf-success"
            ref={successRef}
          >
            <div className="cf-success__circle">
              <svg
                viewBox="0 0 60 60"
                width="60"
                height="60"
              >
                <path
                  className="cf-success__check"
                  d="M14 32 L26 44 L46 20"
                  fill="none"
                  stroke="#F8FAFC"
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>

            <h3>
              ¡Gracias! Recibimos tu solicitud.
            </h3>

            <p>
              Nuestro equipo te contactará en las
              próximas 24 horas hábiles.
            </p>
          </div>
        )}

        <div
          className="cf-illustration"
          aria-hidden="true"
        >
          <svg
            viewBox="0 0 400 320"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect
              className="cf-illustration__bar"
              x="40"
              y="200"
              width="40"
              height="90"
              rx="10"
              fill="#0F172A"
            />

            <rect
              className="cf-illustration__bar"
              x="100"
              y="150"
              width="40"
              height="140"
              rx="10"
              fill="#F97316"
            />

            <rect
              className="cf-illustration__bar"
              x="160"
              y="100"
              width="40"
              height="190"
              rx="10"
              fill="#0F172A"
            />

            <rect
              className="cf-illustration__bar"
              x="220"
              y="60"
              width="40"
              height="230"
              rx="10"
              fill="#F97316"
            />

            <rect
              className="cf-illustration__bar"
              x="280"
              y="20"
              width="40"
              height="270"
              rx="10"
              fill="#06B6D4"
            />

            <path
              className="cf-illustration__arrow"
              d="M30 260 Q140 180 210 120 T380 30"
              fill="none"
              stroke="#06B6D4"
              strokeWidth="4"
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>
    </section>
  );
}