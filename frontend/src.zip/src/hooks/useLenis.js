import { useEffect } from 'react';
import Lenis from 'lenis';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MOTION } from '../utils/constants.js';

gsap.registerPlugin(ScrollTrigger);

let lenisInstance = null;

export const getLenis = () => lenisInstance;

export const stopLenis = () => {
  lenisInstance?.stop();
};

export const startLenis = () => {
  lenisInstance?.start();
};

export function scrollToSection(selector) {
  const target =
    typeof selector === 'string'
      ? document.querySelector(selector)
      : selector;

  if (!target) return;

  if (lenisInstance) {
    lenisInstance.scrollTo(target, {
      offset: MOTION.scrollOffset,
      duration: 1.4,
    });
  } else {
    target.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }
}

export function useLenis(enabled = true) {
  useEffect(() => {
    if (!enabled) {
      if (lenisInstance) {
        lenisInstance.stop();
        lenisInstance.destroy();
        lenisInstance = null;
      }

      ScrollTrigger.update();
      return undefined;
    }

    // Evita crear otra instancia si ya existe.
    if (lenisInstance) {
      return undefined;
    }

    const lenis = new Lenis({
      lerp: 0.1,
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 1.5,
    });

    lenisInstance = lenis;

    const handleScroll = () => {
      ScrollTrigger.update();
    };

    lenis.on('scroll', handleScroll);

    const raf = (time) => {
      lenis.raf(time * 1000);
    };

    gsap.ticker.add(raf);

    // Evita que GSAP interpole el tiempo del ticker y provoque
    // pequeñas inconsistencias con Lenis.
    gsap.ticker.lagSmoothing(0);

    // Lenis puede haber sido creado después de que algunos
    // componentes de la landing montaran sus efectos.
    // Damos un frame para que ScrollTrigger mida el DOM completo.
    requestAnimationFrame(() => {
      ScrollTrigger.refresh();
    });

    return () => {
      gsap.ticker.remove(raf);

      lenis.off('scroll', handleScroll);
      lenis.destroy();

      if (lenisInstance === lenis) {
        lenisInstance = null;
      }

      ScrollTrigger.getAll().forEach((trigger) => {
        if (!trigger.killed) {
          trigger.refresh();
        }
      });
    };
  }, [enabled]);
}