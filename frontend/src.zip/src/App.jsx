import { BrowserRouter } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes.jsx';
import ErrorBoundary from './components/common/ErrorBoundary.jsx';
import { useLenis } from './hooks/useLenis.js';
import { useReducedMotion } from './hooks/useReducedMotion.js';

export default function App() {
  const reduced = useReducedMotion();

  // Lenis se inicializa UNA sola vez desde el nivel de la aplicación.
  // Las páginas/componentes únicamente consumen la instancia existente.
  useLenis(!reduced);

  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </ErrorBoundary>
  );
}